#!/usr/bin/python
list = [ '0' , 'one' ,'2' , 'three' , 4 , 'four' , '5' ]
Slist = [ 'A' ,'B' ,'C' ]

print list
print list [1:3]
print Slist [1]
print list [1:]
print list+Slist